use Bookstore
delete from BooksAndAuthors
delete from Books
delete from Authors
delete from Reviews
go